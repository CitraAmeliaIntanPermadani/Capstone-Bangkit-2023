package com.dicoding.microbizmate.util

class Constant {
    companion object{
        const val EXTRA_ID = "extra id"
    }
}