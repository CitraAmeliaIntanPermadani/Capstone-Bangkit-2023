package com.dicoding.microbizmate.ui.main

import androidx.lifecycle.ViewModel
import com.dicoding.microbizmate.data.StoryRepository


class LoginViewModel(private val storyRepository: StoryRepository): ViewModel() {

    fun postLogin(
        email: String,
        password: String
    ) = storyRepository.postLogin(email, password)
}
