package com.dicoding.microbizmate.ui.main

import androidx.lifecycle.*
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.dicoding.microbizmate.data.StoryRepository
import com.dicoding.microbizmate.data.model.ListStoryItem

class MainViewModel(private val storyRepository: StoryRepository): ViewModel() {
    val getAllStory: LiveData<PagingData<ListStoryItem>> =
        storyRepository.getListStory().cachedIn(viewModelScope)

    fun refreshStories() {
        storyRepository.refreshListStory()
    }
}
