package com.dicoding.microbizmate.data.model

data class AddNewStoryResponse(
	val message: String,
	val error: Boolean
)


