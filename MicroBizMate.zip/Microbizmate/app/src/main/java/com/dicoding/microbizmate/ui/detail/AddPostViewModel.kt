package com.dicoding.microbizmate.ui.detail

import androidx.lifecycle.ViewModel
import com.dicoding.microbizmate.data.StoryRepository
import okhttp3.MultipartBody
import okhttp3.RequestBody

class AddPostViewModel(private val storyRepository: StoryRepository) : ViewModel() {

    fun uploadImage(
        imageFile: MultipartBody.Part,
        desc: RequestBody,
        lat: RequestBody?,
        lon: RequestBody?
    ) =
        storyRepository.uploadImage(imageFile, desc, lat, lon)
}
