package com.dicoding.microbizmate.ui.main

import androidx.lifecycle.ViewModel
import com.dicoding.microbizmate.data.StoryRepository

class RegisterViewModel(private val storyRepository: StoryRepository): ViewModel() {
    fun postRegister(
        name: String,
        email: String,
        password: String
    ) = storyRepository.postRegister(name, email, password)
}
